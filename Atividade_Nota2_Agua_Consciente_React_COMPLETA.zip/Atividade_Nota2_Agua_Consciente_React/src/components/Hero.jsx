export default function Hero({ setPaginaAtual }) {
  return (
    <section className="hero-section" aria-labelledby="titulo-principal">
      <div className="container py-5">
        <div className="row align-items-center g-4">
          <div className="col-lg-7">
            <span className="badge rounded-pill ods-badge">ODS 6 - Água Potável e Saneamento</span>
            <h1 id="titulo-principal" className="display-5 fw-bold mt-3">Pequenas atitudes ajudam a proteger cada gota.</h1>
            <p className="lead mt-3">Aplicação educativa e interativa sobre economia de água, prevenção da poluição e saneamento, usando React, JavaScript e consumo de dados em JSON.</p>
            <div className="d-flex gap-2 flex-wrap mt-4">
              <button className="btn btn-warning fw-semibold" onClick={() => setPaginaAtual('dicas')}>Ver dicas práticas</button>
              <button className="btn btn-outline-light" onClick={() => setPaginaAtual('clima')}>Consultar dados da API</button>
            </div>
          </div>
          <div className="col-lg-5 text-center">
            <img src="/images/hero-agua.svg" className="img-fluid hero-img" alt="Ilustração de uma gota de água com folhas, representando preservação ambiental." />
          </div>
        </div>
      </div>
    </section>
  );
}
