export default function ApiClima() {
  const [dados, setDados] = React.useState(null);
  const [carregando, setCarregando] = React.useState(false);
  const [erro, setErro] = React.useState('');

  async function consultarAPI() {
    setCarregando(true);
    setErro('');
    try {
      const url = 'https://api.open-meteo.com/v1/forecast?latitude=-5.82&longitude=-46.14&current=temperature_2m,relative_humidity_2m,precipitation,weather_code&timezone=America%2FSao_Paulo';
      const resposta = await fetch(url);
      if (!resposta.ok) throw new Error('Falha ao consultar a API.');
      const json = await resposta.json();
      setDados(json.current);
    } catch (error) {
      setErro('Não foi possível carregar os dados externos. Verifique a conexão e tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  React.useEffect(() => {
    consultarAPI();
  }, []);

  return (
    <section className="container py-5" aria-labelledby="titulo-api">
      <div className="api-panel">
        <div className="row align-items-center g-4">
          <div className="col-lg-6">
            <span className="badge text-bg-success">Fetch API + JSON</span>
            <h2 id="titulo-api" className="section-title mt-2">Dados climáticos de Grajaú</h2>
            <p>A aplicação consulta a API pública Open-Meteo para demonstrar consumo de dados externos em JSON. As informações ajudam a relacionar água, clima, umidade e educação ambiental.</p>
            <button className="btn btn-primary" onClick={consultarAPI} disabled={carregando}>{carregando ? 'Atualizando...' : 'Atualizar dados'}</button>
          </div>
          <div className="col-lg-6">
            {erro && <div className="alert alert-danger" role="alert">{erro}</div>}
            {!erro && !dados && <div className="alert alert-info">Carregando dados...</div>}
            {dados && (
              <div className="row g-3" aria-live="polite">
                <div className="col-6"><div className="metric-card"><span>Temperatura</span><strong>{dados.temperature_2m} °C</strong></div></div>
                <div className="col-6"><div className="metric-card"><span>Umidade</span><strong>{dados.relative_humidity_2m}%</strong></div></div>
                <div className="col-6"><div className="metric-card"><span>Precipitação</span><strong>{dados.precipitation} mm</strong></div></div>
                <div className="col-6"><div className="metric-card"><span>Atualização</span><strong>{dados.time?.replace('T', ' ')}</strong></div></div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
