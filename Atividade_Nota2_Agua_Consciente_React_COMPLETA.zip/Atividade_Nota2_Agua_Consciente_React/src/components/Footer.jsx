export default function Footer() {
  return (
    <footer className="app-footer mt-auto">
      <div className="container py-4 d-flex flex-column flex-md-row justify-content-between gap-2">
        <p className="mb-0">Água Consciente - ODS 6 | Desenvolvimento Web</p>
        <p className="mb-0">React + JavaScript + Fetch API + Bootstrap</p>
      </div>
    </footer>
  );
}
