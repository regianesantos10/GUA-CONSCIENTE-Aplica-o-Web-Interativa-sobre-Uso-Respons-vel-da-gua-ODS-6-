export default function CardsODS() {
  const cards = [
    { titulo: 'Água segura', texto: 'Informa sobre o uso consciente e a importância da água potável.' },
    { titulo: 'Qualidade da água', texto: 'Orienta sobre descarte correto de resíduos e prevenção da poluição.' },
    { titulo: 'Uso eficiente', texto: 'Apresenta práticas simples para economizar e reduzir desperdícios.' }
  ];
  return (
    <section className="container py-5" aria-labelledby="ods6">
      <h2 id="ods6" className="section-title">Relação com o ODS 6</h2>
      <div className="row g-3 mt-2">
        {cards.map((card) => (
          <article className="col-md-4" key={card.titulo}>
            <div className="info-card h-100">
              <h3>{card.titulo}</h3>
              <p>{card.texto}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
