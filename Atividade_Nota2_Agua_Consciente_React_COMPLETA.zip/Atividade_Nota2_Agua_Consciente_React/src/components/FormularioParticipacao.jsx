export default function FormularioParticipacao() {
  const [form, setForm] = React.useState({ nome: '', tipo: '', mensagem: '' });
  const [alerta, setAlerta] = React.useState('');

  function atualizar(evento) {
    const { name, value } = evento.target;
    setForm((anterior) => ({ ...anterior, [name]: value }));
  }

  function enviar(evento) {
    evento.preventDefault();
    if (!form.nome || !form.tipo || !form.mensagem) {
      setAlerta('Preencha todos os campos antes de enviar a sugestão.');
      return;
    }
    setAlerta(`Obrigado, ${form.nome}. Sua sugestão sobre ${form.tipo} foi registrada para análise.`);
    setForm({ nome: '', tipo: '', mensagem: '' });
  }

  return (
    <section className="container py-5" aria-labelledby="titulo-participe">
      <div className="row g-4">
        <div className="col-lg-5">
          <span className="badge text-bg-warning">Tratamento de eventos</span>
          <h2 id="titulo-participe" className="section-title mt-2">Participe da construção</h2>
          <p>O formulário demonstra validação simples, controle de estado e resposta ao usuário. Nesta versão, os dados não são enviados para banco de dados.</p>
          <img src="/images/comunidade.svg" className="img-fluid rounded-4" alt="Ilustração de pessoas em uma ação comunitária relacionada ao cuidado com a água." />
        </div>
        <div className="col-lg-7">
          <form className="form-card" onSubmit={enviar} noValidate>
            {alerta && <div className="alert alert-primary" role="status">{alerta}</div>}
            <div className="mb-3">
              <label htmlFor="nome" className="form-label">Nome</label>
              <input id="nome" name="nome" className="form-control" value={form.nome} onChange={atualizar} placeholder="Digite seu nome" />
            </div>
            <div className="mb-3">
              <label htmlFor="tipo" className="form-label">Tipo de contribuição</label>
              <select id="tipo" name="tipo" className="form-select" value={form.tipo} onChange={atualizar}>
                <option value="">Selecione</option>
                <option>Dica de economia de água</option>
                <option>Problema de desperdício</option>
                <option>Ação educativa</option>
              </select>
            </div>
            <div className="mb-3">
              <label htmlFor="mensagem" className="form-label">Mensagem</label>
              <textarea id="mensagem" name="mensagem" className="form-control" rows="5" value={form.mensagem} onChange={atualizar} placeholder="Descreva sua sugestão"></textarea>
            </div>
            <button className="btn btn-primary" type="submit">Registrar sugestão</button>
          </form>
        </div>
      </div>
    </section>
  );
}
