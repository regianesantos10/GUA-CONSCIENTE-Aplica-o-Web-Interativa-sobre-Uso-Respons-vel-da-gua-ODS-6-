export default function Header({ paginaAtual, setPaginaAtual }) {
  const itens = [
    { id: 'inicio', label: 'Início' },
    { id: 'dicas', label: 'Dicas' },
    { id: 'clima', label: 'Dados da API' },
    { id: 'participe', label: 'Participe' }
  ];

  return (
    <header className="app-header">
      <a className="skip-link" href="#conteudo">Pular para o conteúdo principal</a>
      <nav className="navbar navbar-expand-lg navbar-dark" aria-label="Navegação principal">
        <div className="container">
          <button className="navbar-brand brand-button" onClick={() => setPaginaAtual('inicio')} aria-label="Voltar para o início">
            <img src="/images/logo-agua.svg" alt="" className="brand-logo" />
            Água Consciente
          </button>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Abrir menu">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="menu">
            <ul className="navbar-nav ms-auto">
              {itens.map((item) => (
                <li className="nav-item" key={item.id}>
                  <button
                    className={`nav-link nav-button ${paginaAtual === item.id ? 'active' : ''}`}
                    aria-current={paginaAtual === item.id ? 'page' : undefined}
                    onClick={() => setPaginaAtual(item.id)}
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
}
