import { dicas } from '../data/dicas.js';

export default function Dicas() {
  const [busca, setBusca] = React.useState('');
  const filtradas = dicas.filter((dica) =>
    `${dica.titulo} ${dica.categoria} ${dica.texto}`.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <section className="container py-5" aria-labelledby="titulo-dicas">
      <div className="d-flex flex-column flex-lg-row justify-content-between gap-3 align-items-lg-end">
        <div>
          <span className="badge text-bg-primary">Interatividade com JavaScript</span>
          <h2 id="titulo-dicas" className="section-title mt-2">Dicas para cuidar da água</h2>
          <p className="text-muted mb-0">Digite uma palavra e veja os cartões serem filtrados em tempo real.</p>
        </div>
        <div className="search-box">
          <label htmlFor="busca" className="form-label fw-semibold">Buscar dica</label>
          <input id="busca" className="form-control" value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Ex.: óleo, vazamento, nascente" />
        </div>
      </div>
      <p className="mt-3 mb-0"><strong>{filtradas.length}</strong> resultado(s) encontrado(s).</p>
      <div className="row g-3 mt-2">
        {filtradas.map((dica) => (
          <article className="col-md-6 col-xl-3" key={dica.id}>
            <div className="tip-card h-100">
              <span>{dica.categoria}</span>
              <h3>{dica.titulo}</h3>
              <p>{dica.texto}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
