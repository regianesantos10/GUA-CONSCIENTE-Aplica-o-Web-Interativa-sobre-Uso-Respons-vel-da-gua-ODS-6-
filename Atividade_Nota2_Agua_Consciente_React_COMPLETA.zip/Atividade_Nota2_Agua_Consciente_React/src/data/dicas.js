export const dicas = [
  { id: 1, titulo: 'Feche a torneira', categoria: 'Uso doméstico', texto: 'Fechar a torneira ao escovar os dentes reduz desperdícios diários e ajuda a preservar a água potável.' },
  { id: 2, titulo: 'Repare vazamentos', categoria: 'Manutenção', texto: 'Pequenos vazamentos podem representar grande perda de água ao longo do mês.' },
  { id: 3, titulo: 'Reutilize água quando possível', categoria: 'Reuso', texto: 'Água da lavagem de roupas pode ser usada para lavar calçadas, respeitando cuidados de higiene.' },
  { id: 4, titulo: 'Não descarte óleo na pia', categoria: 'Qualidade da água', texto: 'O descarte de óleo prejudica redes de esgoto, rios e solos. O ideal é armazenar e destinar corretamente.' },
  { id: 5, titulo: 'Use balde em vez de mangueira', categoria: 'Economia', texto: 'Para lavar veículos e áreas externas, o balde reduz o consumo e facilita o controle da água usada.' },
  { id: 6, titulo: 'Proteja nascentes', categoria: 'Meio ambiente', texto: 'A proteção de nascentes e matas ciliares contribui para a segurança hídrica da comunidade.' },
  { id: 7, titulo: 'Evite lixo nas ruas', categoria: 'Saneamento', texto: 'Resíduos nas ruas podem entupir bueiros, poluir corpos d’água e agravar alagamentos.' },
  { id: 8, titulo: 'Compartilhe informação', categoria: 'Educação ambiental', texto: 'A educação ambiental ajuda famílias e estudantes a adotarem hábitos sustentáveis.' }
];
