import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import CardsODS from './components/CardsODS.jsx';
import Dicas from './components/Dicas.jsx';
import ApiClima from './components/ApiClima.jsx';
import FormularioParticipacao from './components/FormularioParticipacao.jsx';
import Footer from './components/Footer.jsx';

export default function App() {
  const [paginaAtual, setPaginaAtual] = React.useState('inicio');

  React.useEffect(() => {
    const titulo = {
      inicio: 'Água Consciente - ODS 6',
      dicas: 'Dicas - Água Consciente',
      clima: 'Dados da API - Água Consciente',
      participe: 'Participe - Água Consciente'
    };
    document.title = titulo[paginaAtual] || 'Água Consciente';
  }, [paginaAtual]);

  return (
    <div className="app-shell">
      <Header paginaAtual={paginaAtual} setPaginaAtual={setPaginaAtual} />
      <main id="conteudo" tabIndex="-1">
        {paginaAtual === 'inicio' && <><Hero setPaginaAtual={setPaginaAtual} /><CardsODS /></>}
        {paginaAtual === 'dicas' && <Dicas />}
        {paginaAtual === 'clima' && <ApiClima />}
        {paginaAtual === 'participe' && <FormularioParticipacao />}
      </main>
      <Footer />
    </div>
  );
}
