# Água Consciente - ODS 6

Projeto da disciplina Desenvolvimento de Web, continuação da Nota 1.

## Tecnologias
- React
- JavaScript
- Bootstrap
- Fetch API
- Open-Meteo API

## Como executar
1. Instale o Node.js.
2. Abra a pasta do projeto no terminal.
3. Execute: `npm install`
4. Execute: `npm run dev`
5. Acesse o endereço indicado pelo Vite.

## Como publicar
A aplicação pode ser publicada no Vercel, Netlify ou GitHub Pages. Depois da publicação, inserir o link nos slides antes da entrega final no AVA.

## Observação
Os links de GitHub e de hospedagem devem ser substituídos pelos links reais da equipe após o envio dos arquivos para a plataforma escolhida.
