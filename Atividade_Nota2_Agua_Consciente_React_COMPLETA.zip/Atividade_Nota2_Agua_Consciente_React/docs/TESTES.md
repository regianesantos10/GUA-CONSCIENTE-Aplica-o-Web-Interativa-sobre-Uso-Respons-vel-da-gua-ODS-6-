# Testes realizados

- Navegação SPA entre Início, Dicas, Dados da API e Participe sem recarregar a página.
- Busca de dicas por palavra-chave, com atualização em tempo real.
- Formulário com validação de campos obrigatórios e mensagem ao usuário.
- Consumo de dados externos com Fetch API e tratamento de JSON.
- Tratamento de erro caso a API não responda.
- Verificação visual em tela de computador e celular.
- Conferência de contraste, textos alternativos, labels e navegação por teclado.
